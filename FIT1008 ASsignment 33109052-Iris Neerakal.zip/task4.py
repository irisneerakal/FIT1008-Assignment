"""
ADD COMMENTS TO THIS FILE 
"""
from typing import List, TypeVar

T = TypeVar('T')

def insertion_sort(the_list: List[T]):
    '''
    assigning to the variable "length" the length of the inputted list
    '''
    length = len(the_list) 
    '''
    variable i have values of range 1 to length of list
    '''
    for i in range(1, length):
        '''
        Assigning to the variable "key" the value at index i of inputted list 
        ''' 
        key = the_list[i] 
        '''
        Variable j equal to i-1
        '''
        j = i-1
        '''
        While loop runs only if j is greater than or equal to 0 and if variable key is less than the value from the list with index j
        If the condition is true the value of the list having index j+1 changes to the value of the list at index j
        The while loop runs until a condition is broken
        '''
        while j >= 0 and key < the_list[j] : 
            the_list[j + 1] = the_list[j]
            j -= 1
        '''
        The value at index j+1 of the list changes to the value of the key 
        '''
        the_list[j + 1] = key
        '''
        The program then goes back to the for loop and starts again until i is equal to the
        length of the list
        '''

def main() -> None:
    '''
    assigning to variable "arr"  an list of numbers
    Passing this variable through the insertion _sort function and calling it
    '''
    arr = [6, -2, 7, 4, -10]
    insertion_sort(arr)
    '''
    Using the new array we get after running it through the function 
    Variable i has range from 0 to length of variable "arr"
    Printing each element of this list in a single line with spaces 
    '''
    for i in range(len(arr)):
        print (arr[i], end=" ")
    print()
main()