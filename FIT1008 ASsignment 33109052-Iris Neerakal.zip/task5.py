"""
ADD COMMENTS TO THIS FILE 
"""


def print_combination(arr, n, r):
    '''
    Creating an array "data" having inital values as 0 and size with number of columns as "r"
    '''    

    data = [0] * r
    '''
    passing original array, length of original array, total number of events, index value, data array, 0
    to function combination_aux
    '''
    combination_aux(arr, n, r, 0, data, 0)
 
def combination_aux(arr, n, r, index, data, i):
    '''
    Check if index is equal to r
    '''
    if (index == r):
        '''
        Variable j have values from 0 to r
        if condition is true it prints the value in data array having index j
        '''
        for j in range(r):
            print(data[j], end = " ")
        '''
        Prints a newline
        '''
        print()
        '''
        Returns back to the calling function
        '''
        return
    '''
    If i is greater than or equal to the size of the original array
    '''
    if (i >= n):
        '''
        Returns back to the calling function
        '''
        return
    '''
    if index is not equal to r and i is less than size of the original array

    Changing the value of the data array at the index with the oringial array at index i
    This will modify the data array 
    '''
    data[index] = arr[i]

    combination_aux(arr, n, r, index + 1,
                    data, i + 1)
    '''
    After calling the function 3 times the index will become 3
    and the data array's elements will be displayed
    For the next recursive call, i will increase by 1 and the index will decrease by 1
    Which we then use to display the combination until the end of the original array
    '''
 
    combination_aux(arr, n, r, index,
                    data, i + 1)
    
 
def main():
    '''
    assigning variable "arr" with a list of numbers
    '''
    arr = [1, 2, 3, 4, 5]
    '''
    Total number of events (r) =3
    Length of "arr" = n
    '''
    r = 3
    n = len(arr)
    '''
    passing the element to the function print_combination and running it
    '''
    print_combination(arr, n, r)

main()